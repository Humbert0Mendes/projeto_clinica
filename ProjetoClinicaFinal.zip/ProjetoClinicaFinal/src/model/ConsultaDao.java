package model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ConsultaDao extends GenericDao {

	public void salvar(Consulta consulta) throws SQLException {
		String insert = "INSERT INTO MEDICO () VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		save(insert, consulta.getNm_medico(), consulta.getIdade(), consulta.getSexo(), consulta.getDt_nasc_pac(),
				consulta.getTp_consulta(), consulta.getTp_medico(), consulta.getNm_medico(), consulta.getDt_consulta(),
				consulta.getMatricula_pac(), consulta.getObs_pac());
	}

	public void alterar(Consulta consulta) throws SQLException {
		String update = "UPDATE CONSULTA" + "SET nm_paciente = ?" + "WHERE id = ?";
		update(update, consulta.getNm_paciente(), consulta.getId());
	}

	public void excluir(long id) throws SQLException {
		String delete = "DELETE FROM CONSULTA WHERE id= ?";
		delete(delete, id);
	}

	public List findListaConsulta() throws SQLException {
		List consultas = new ArrayList();

		String select = "SELECT * FROM CONSULTA";

		PreparedStatement stmt = getConnection().prepareStatement(select);

		ResultSet rs = stmt.executeQuery();

		while (rs.next()) {
			Consulta consulta = new Consulta();
			consulta.setId(rs.getLong("id"));
			consulta.setNm_medico(rs.getString("nm_medico"));
			consulta.setIdade(rs.getString("idade"));
			consulta.setSexo(rs.getString("sexo"));
			consulta.setDt_nasc_pac(rs.getDate("dt_nasc_pac"));
			consulta.setTp_consulta(rs.getString("tp_consulta"));
			consulta.setTp_medico(rs.getString("tp_medico"));
			consulta.setDt_consulta(rs.getDate("dt_consulta"));
			consulta.setMatricula_pac(rs.getString("matricula_pac"));
			consulta.setObs_pac(rs.getString("observacao_pac"));
			consultas.add(consulta);
		}

		rs.close();
		stmt.close();

		return consultas;
	}

	public Consulta findByName(String nm_paciente) throws SQLException {

		String select = "SELECT * FROM CONSULTA WHERE nm_paciente = ?";
		Consulta consulta = null;
		PreparedStatement stmt = getConnection().prepareStatement(select);

		stmt.setString(1, nm_paciente);
		ResultSet rs = stmt.executeQuery();

		while (rs.next()) {
			consulta = new Consulta();
			consulta.setId(rs.getLong("id"));
			consulta.setNm_medico(rs.getString("nm_medico"));
			consulta.setIdade(rs.getString("idade"));
			consulta.setSexo(rs.getString("sexo"));
			consulta.setDt_nasc_pac(rs.getDate("dt_nasc_pac"));
			consulta.setTp_consulta(rs.getString("tp_consulta"));
			consulta.setTp_medico(rs.getString("tp_medico"));
			consulta.setDt_consulta(rs.getDate("dt_consulta"));
			consulta.setMatricula_pac(rs.getString("matricula_pac"));
			consulta.setObs_pac(rs.getString("observacao_pac"));

		}
		rs.close();
		stmt.close();
		return consulta;

	}

}
