package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionDataBase {
	
	private static final String URL_POSTGRES = "jdbc:postgresql://localhost:5432/postgres";
	
	private static final String USER = "postgres";
	
	private static final String PASS = "123456";
	
	public static Connection getConnection() {
		System.out.println("Conectando ao Banco");
		
		try {
			return DriverManager.getConnection(URL_POSTGRES, USER, PASS);
		}catch(SQLException e){
			throw new RuntimeException(e);
		}
	}

}
