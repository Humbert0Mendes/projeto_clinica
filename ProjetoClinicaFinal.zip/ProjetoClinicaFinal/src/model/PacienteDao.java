package model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PacienteDao extends GenericDao {

	public void salvar(Paciente paciente) throws SQLException {
		String insert = "INSERT INTO PACIENTE (nm_paciente, sexo, nm_familiar, doenca_cronica, cpf, matricula, idade, dt_nasc, tp_sangue, observacao) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		save(insert, paciente.getNome(), paciente.getSexo(), paciente.getParente(), paciente.getDoenca(),
				paciente.getCpf(), paciente.getMatricula(), paciente.getIdade(), paciente.getDt_nasc(),
				paciente.getTp_sangue(), paciente.getObs());
	}

	public void alterar(Paciente paciente) throws SQLException {
		String update = "UPDATE PACIENTE" + "SET nm_paciente = ?" + "WHERE id = ?";
		update(update, paciente.getNome(), paciente.getId());
	}

	public void excluir(long id) throws SQLException {
		String delete = "DELETE FROM PACIENTE WHERE id= ?";
		delete(delete, id);
	}

	public List findPacientes() throws SQLException {
		List pacientes = new ArrayList();

		String select = "SELECT * FROM PACIENTE";

		PreparedStatement stmt = getConnection().prepareStatement(select);

		ResultSet rs = stmt.executeQuery();

		while (rs.next()) {
			Paciente paciente = new Paciente();
			paciente.setId(rs.getLong("id"));
			paciente.setNome(rs.getString("nome"));
			paciente.setSexo(rs.getString("sexo"));
			paciente.setParent(rs.getString("nm_familiar"));
			paciente.setDoenca(rs.getString(""));
			paciente.setCpf(rs.getString("cpf"));
			paciente.setMatricula(rs.getString("matricula"));
			paciente.setIdade(rs.getString("idade"));
			paciente.setDt_nasc(rs.getDate("dt_nasc"));
			paciente.setTp_sangue(rs.getString("tp_sangue"));
			paciente.setObs(rs.getString("observacao"));
			pacientes.add(paciente);
		}

		rs.close();
		stmt.close();

		return pacientes;
	}

	public Paciente findByName(String nome) throws SQLException {
		String select = "SELECT * FROM PACIENTE WHERE nm_paciente = ?";
		Paciente paciente = null;
		PreparedStatement stmt = getConnection().prepareStatement(select);

		stmt.setString(1, nome);
		ResultSet rs = stmt.executeQuery();

		while (rs.next()) {
			paciente = new Paciente();
			paciente.setId(rs.getLong("id"));
			paciente.setNome(rs.getString("nm_paciente"));
			paciente.setSexo(rs.getString("sexo"));
			paciente.setParent(rs.getString("nm_familiar"));
			paciente.setDoenca(rs.getString(""));
			paciente.setCpf(rs.getString("cpf"));
			paciente.setMatricula(rs.getString("matricula"));
			paciente.setIdade(rs.getString("idade"));
			paciente.setDt_nasc(rs.getDate("dt_nasc"));
			paciente.setTp_sangue(rs.getString("tp_sangue"));
			paciente.setObs(rs.getString("observacao"));
		}

		rs.close();
		stmt.close();
		return paciente;
	}

}
