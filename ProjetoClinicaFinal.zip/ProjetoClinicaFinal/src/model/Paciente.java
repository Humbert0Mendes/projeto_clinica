package model;

import java.sql.Date;

public class Paciente {

	private Long id;
	private String nm_paciente;
	private String sexo;
	private String nm_familiar;
	private String doenca_cronica;
	private String cpf;
	private String matricula;
	private String idade;
	private Date dt_nasc;
	private String tp_sangue;
	private String observacao;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNome() {
		return nm_paciente;
	}

	public void setNome(String nm_paciente) {
		this.nm_paciente = nm_paciente;
	}

	public String getSexo() {
		return sexo;
	}

	public void setSexo(String sexo) {
		this.sexo = sexo;
	}

	public String getParente() {
		return nm_familiar;
	}

	public void setParent(String nm_familiar) {
		this.nm_familiar = nm_familiar;
	}

	public String getDoenca() {
		return doenca_cronica;
	}

	public void setDoenca(String doenca_cronica) {
		this.doenca_cronica = doenca_cronica;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}
	
	public String getIdade() {
		return idade;
	}
	
	public void setIdade(String idade) {
		this.idade = idade;
	}
	
	public Date getDt_nasc() {
		return dt_nasc;
	}
	
	public void setDt_nasc(Date dt_nasc) {
		this.dt_nasc = dt_nasc;
	}
	
	public String getTp_sangue() {
		return tp_sangue;
	}
	
	public void setTp_sangue(String tp_sangue) {
		this.tp_sangue = tp_sangue;
	}
	
	public String getObs() {
		return observacao;
	}
	
	public void setObs(String observacao) {
		this.observacao = observacao;
	}
}
