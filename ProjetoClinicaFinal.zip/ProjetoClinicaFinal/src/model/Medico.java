package model;

import java.sql.Date;

public class Medico {

	private Long id;
	private String nm_medico;
	private String cpf;
	private String sexo;
	private String idade;
	private String tp_prestador;
	private String conselho;
	private String espec;
	private Date dt_nascimento;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNm_medico() {
		return nm_medico;
	}

	public void setNm_medico(String nm_medico) {
		this.nm_medico = nm_medico;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getSexo() {
		return sexo;
	}

	public void setSexo(String sexo) {
		this.sexo = sexo;
	}

	public String getIdade() {
		return idade;
	}

	public void setIdade(String idade) {
		this.idade = idade;
	}

	public String getTp_prestador() {
		return tp_prestador;
	}

	public void setTp_prestador(String tp_prestador) {
		this.tp_prestador = tp_prestador;
	}

	public String getConselho() {
		return conselho;
	}

	public void setConselho(String conselho) {
		this.conselho = conselho;
	}

	public String getEspec() {
		return espec;
	}

	public void setEspec(String espec) {
		this.espec = espec;
	}

	public Date getDt_nascimento() {
		return dt_nascimento;
	}

	public void setDt_nascimento(Date dt_nascimento) {
		this.dt_nascimento = dt_nascimento;
	}

}
