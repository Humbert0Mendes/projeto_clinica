package model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.postgresql.core.ConnectionFactory;
import org.postgresql.core.v3.ConnectionFactoryImpl;

public class UsuarioDao extends GenericDao {

	public boolean checkUsuario(String usuario, String senha) throws SQLException {

		
		ResultSet rs = null;
		boolean check = false;
		
		
		try {
		String select = "SELECT * FROM USUARIOS WHERE usuario = ? and senha = ? ";

		PreparedStatement stmt = getConnection().prepareStatement(select);
		stmt.setString(1, usuario);
		stmt.setString(2, senha);
		 rs = stmt.executeQuery();

		if (rs.next()) {
			
			check = true;
		}
		
	}catch(SQLException e) {
		Logger.getLogger(UsuarioDao.class.getName()).log(Level.SEVERE, null, e);
	}finally {
		rs.close();
		
	}
		
		
		return check;
}

}
