package model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MedicoDao extends GenericDao {

	public void salvar(Medico medico) throws SQLException {
		String insert = "INSERT INTO MEDICO (nm_medico, cpf, sexo, idade, tp_prestador, conselho, espec, dt_nascimento) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
		save(insert, medico.getNm_medico(), medico.getCpf(), medico.getSexo(), medico.getIdade(),
				medico.getTp_prestador(), medico.getConselho(), medico.getEspec(), medico.getDt_nascimento());
	}

	public void alterar(Medico medico) throws SQLException {
		String update = "UPDATE MEDICO" + "SET nm_paciente = ?" + "WHERE id = ?";
		update(update, medico.getNm_medico(), medico.getId());
	}

	public void excluir(long id) throws SQLException {
		String delete = "DELETE FROM MEDICO WHERE id= ?";
		delete(delete, id);
	}

	public List findListaMedico() throws SQLException {
		List medicos = new ArrayList();

		String select = "SELECT * FROM MEDICO";

		PreparedStatement stmt = getConnection().prepareStatement(select);

		ResultSet rs = stmt.executeQuery();

		while (rs.next()) {
			Medico medico = new Medico();
			medico.setId(rs.getLong("id"));
			medico.setNm_medico(rs.getString("nm_medico"));
			medico.setCpf(rs.getString("cpf"));
			medico.setSexo(rs.getString("sexo"));
			medico.setIdade(rs.getString("idade"));
			medico.setTp_prestador(rs.getString("tp_prestador"));
			medico.setConselho(rs.getString("conselho"));
			medico.setEspec(rs.getString("espec"));
			medico.setDt_nascimento(rs.getDate("dt_nascimento"));
			medicos.add(medico);
		}

		rs.close();
		stmt.close();

		return medicos;
	}

	public Medico findByName(String nm_medico) throws SQLException {
		String select = "SELECT * FROM MEDICO WHERE nm_medico = ?";
		Medico medico = null;
		PreparedStatement stmt = getConnection().prepareStatement(select);

		stmt.setString(1, nm_medico);
		ResultSet rs = stmt.executeQuery();

		while (rs.next()) {
			medico = new Medico();
			medico.setId(rs.getLong("id"));
			medico.setNm_medico(rs.getString("nm_medico"));
			medico.setCpf(rs.getString("cpf"));
			medico.setSexo(rs.getString("sexo"));
			medico.setIdade(rs.getString("idade"));
			medico.setTp_prestador(rs.getString("tp_prestador"));
			medico.setConselho(rs.getString("conselho"));
			medico.setEspec(rs.getString("espec"));
			medico.setDt_nascimento(rs.getDate("dt_nascimento"));

		}
		rs.close();
		stmt.close();
		return medico;

	}

}
