package model;

import java.sql.Date;

public class Consulta {

	private Long id;
	private String nm_paciente;
	private String idade;
	private String sexo;
	private Date dt_nasc_pac;
	private String tp_consulta;
	private String tp_medico;
	private String nm_medico;
	private Date dt_consulta;
	private String matricula_pac;
	private String obs_pac;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNm_paciente() {
		return nm_paciente;
	}

	public void setNm_paciente(String nm_paciente) {
		this.nm_paciente = nm_paciente;
	}

	public String getIdade() {
		return idade;
	}

	public void setIdade(String idade) {
		this.idade = idade;
	}

	public String getSexo() {
		return sexo;
	}

	public void setSexo(String sexo) {
		this.sexo = sexo;
	}

	public Date getDt_nasc_pac() {
		return dt_nasc_pac;
	}

	public void setDt_nasc_pac(Date dt_nasc_pac) {
		this.dt_nasc_pac = dt_nasc_pac;
	}

	public String getTp_consulta() {
		return tp_consulta;
	}

	public void setTp_consulta(String tp_consulta) {
		this.tp_consulta = tp_consulta;
	}

	public String getTp_medico() {
		return tp_medico;
	}

	public void setTp_medico(String tp_medico) {
		this.tp_medico = tp_medico;
	}

	public String getNm_medico() {
		return nm_medico;
	}

	public void setNm_medico(String nm_medico) {
		this.nm_medico = nm_medico;
	}

	public Date getDt_consulta() {
		return dt_consulta;
	}

	public void setDt_consulta(Date dt_consulta) {
		this.dt_consulta = dt_consulta;
	}

	public String getMatricula_pac() {
		return matricula_pac;
	}

	public void setMatricula_pac(String matricula_pac) {
		this.matricula_pac = matricula_pac;
	}

	public String getObs_pac() {
		return obs_pac;
	}

	public void setObs_pac(String obs_pac) {
		this.obs_pac = obs_pac;
	}

}
