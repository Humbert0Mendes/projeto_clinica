package view;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import controller.ConsultaController;
import controller.MedicoController;
import controller.PacienteController;
import model.Consulta;
import model.Medico;

public class ConsultaFrame extends JFrame {

	JPanel marcarConsulta;
	JTextField nm_paciente, vIdade, cSexo, txtData, tp_consulta, tp_medico, nm_medico, txtDataCad, vmatricula, cObs;
	JButton btnLimpar, btnSalvar, btnExcluir, btnConsultar;

	private List listaConsulta = new ConsultaController().listaConsulta();
	private int registroAtual = 0;
	private Long key;

	public ConsultaFrame() {
		setTitle("Marcar Consulta");
		setSize(800, 600);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setLayout(null);

		// Tela de Cadastrar Paciente
		marcarConsulta = new JPanel();
		marcarConsulta.setBounds(30, 50, 700, 700);
		setContentPane(marcarConsulta);
		marcarConsulta.setLayout(null);
		marcarConsulta.setSize(700, 500);
		marcarConsulta.setBorder(new EmptyBorder(5, 5, 5, 5));

		// Campo Dados do Paciente

		// Campo Nome
		JLabel nomePaciente = new JLabel("Nome Paciente");
		nomePaciente.setFont(new Font("Tahoma", Font.BOLD, 10));
		nomePaciente.setBounds(30, 5, 90, 20);

		nm_paciente = new JTextField();
		nm_paciente.setBounds(30, 27, 250, 25);
		marcarConsulta.add(nomePaciente);
		marcarConsulta.add(nm_paciente);

		// Campo Idade
		JLabel idade = new JLabel("Idade");
		idade.setFont(new Font("Tahoma", Font.BOLD, 10));
		idade.setBounds(300, 5, 70, 20);

		vIdade = new JTextField();
		vIdade.setBounds(300, 27, 50, 25);
		marcarConsulta.add(idade);
		marcarConsulta.add(vIdade);

		// Campo Sexo
		JLabel lSexo = new JLabel("Sexo");
		lSexo.setFont(new Font("Tahoma", Font.BOLD, 10));
		lSexo.setBounds(370, 5, 70, 20);
		marcarConsulta.add(lSexo);

		cSexo = new JTextField();
		cSexo.setBounds(370, 27, 180, 25);
		marcarConsulta.add(cSexo);

		// Campo Data
		JLabel lData = new JLabel("Data Nascimento");
		lData.setFont(new Font("Tahoma", Font.BOLD, 10));
		lData.setBounds(570, 5, 90, 20);
		marcarConsulta.add(lData);

		txtData = new JTextField();
		txtData.setBounds(570, 27, 120, 25);
		marcarConsulta.add(txtData);

		// Campo Tipo de Consulta

		JLabel l_consulta = new JLabel("Tipo de Consulta");
		l_consulta.setFont(new Font("Tahoma", Font.BOLD, 10));
		l_consulta.setBounds(30, 50, 90, 20);
		marcarConsulta.add(l_consulta);

		tp_consulta = new JTextField();
		tp_consulta.setBounds(30, 70, 250, 25);
		marcarConsulta.add(tp_consulta);

		// Campo M�dico
		JLabel l_medico = new JLabel("Tipo M�dico");
		l_medico.setFont(new Font("Tahoma", Font.BOLD, 10));
		l_medico.setBounds(300, 50, 70, 20);

		tp_medico = new JTextField();
		tp_medico.setBounds(300, 70, 250, 25);
		marcarConsulta.add(tp_medico);
		marcarConsulta.add(l_medico);

		// Campo M�dico
		JLabel nl_medico = new JLabel("Nome M�dico");
		nl_medico.setFont(new Font("Tahoma", Font.BOLD, 10));
		nl_medico.setBounds(570, 50, 70, 20);

		nm_medico = new JTextField();
		nm_medico.setBounds(570, 70, 120, 25);
		marcarConsulta.add(nm_medico);
		marcarConsulta.add(nl_medico);

		// Campo Data da Consulta
		JLabel lDataCad = new JLabel("Data da Consulta");
		lDataCad.setFont(new Font("Tahoma", Font.BOLD, 10));
		lDataCad.setBounds(30, 100, 90, 20);
		marcarConsulta.add(lDataCad);

		txtDataCad = new JTextField();
		txtDataCad.setBounds(30, 120, 80, 25);
		marcarConsulta.add(txtDataCad);

		// Campo Matricula
		JLabel matricula = new JLabel("Matr�cula");
		matricula.setFont(new Font("Tahoma", Font.BOLD, 10));
		matricula.setBounds(140, 100, 90, 20);
		marcarConsulta.add(matricula);

		vmatricula = new JTextField();
		vmatricula.setBounds(140, 120, 140, 25);
		marcarConsulta.add(vmatricula);

		// Campo Obs
		JLabel lObs = new JLabel("Observa��o");
		lObs.setFont(new Font("Tahoma", Font.BOLD, 10));
		lObs.setBounds(30, 150, 70, 20);
		marcarConsulta.add(lObs);

		cObs = new JTextField();
		cObs.setFont(new Font("Tahoma", Font.BOLD, 10));
		cObs.setBounds(30, 170, 250, 50);
		marcarConsulta.add(cObs);

		// Bot�o Limpar
		btnLimpar = new JButton("Limpar");
		btnLimpar.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnLimpar.setBackground(new Color(20, 28, 100));
		btnLimpar.setForeground(new Color(255, 255, 255));
		btnLimpar.setBounds(300, 120, 140, 25);
		marcarConsulta.add(btnLimpar);

		// Bot�o Salvar
		btnSalvar = new JButton("Salvar");
		btnSalvar.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnSalvar.setBackground(new Color(20, 28, 100));
		btnSalvar.setForeground(new Color(255, 255, 255));
		btnSalvar.setBounds(300, 170, 140, 50);
		marcarConsulta.add(btnSalvar);

		// Bot�o Consulta
		btnConsultar = new JButton("Consultar Paciente");
		btnConsultar.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnConsultar.setBackground(new Color(20, 28, 100));
		btnConsultar.setForeground(new Color(255, 255, 255));
		btnConsultar.setBounds(30, 240, 180, 25);
		marcarConsulta.add(btnConsultar);

		// Bot�o excluir
		btnExcluir = new JButton("Excluir");
		btnExcluir.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnExcluir.setBackground(new Color(20, 28, 100));
		btnExcluir.setForeground(new Color(255, 255, 255));
		btnExcluir.setBounds(440, 180, 120, 25);
		marcarConsulta.add(btnExcluir);

		// Implementando a��o dos bot�es
		// Salvar
		btnSalvar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				clickSalvar();
			}
		});

		// Excluir
		btnExcluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				clickExcluir();
			}
		});

		// Limpar
		btnLimpar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				clearFields();
				registroAtual = 0;
			}

		});

		// Consultar
		btnConsultar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				clickConsultar();
			}
		});

	}

	private void clickSalvar() {
		ConsultaController cc = new ConsultaController();

		try {
			cc.salvar(nm_medico.getText(), vIdade.getText(), cSexo.getText(), txtData.getText(), tp_consulta.getText(),
					tp_medico.getText(), nm_medico.getText(), txtDataCad.getText(), vmatricula.getText(),
					cObs.getText());
			JOptionPane.showMessageDialog(this, "Consulta salvo com sucesso!");
			clearFields();
			listaConsulta = new ConsultaController().listaConsulta();
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(this, "Nao foi possivel salvar contato!n" + e.getLocalizedMessage());
		} catch (ParseException e) {
			JOptionPane.showMessageDialog(this, "Data possui formato inv�lido!n" + e.getLocalizedMessage());
		}
	}

	private void clickExcluir() {
		ConsultaController cc = new ConsultaController();
		long id = ((Consulta) listaConsulta.get(registroAtual)).getId();

		try {
			cc.excluir(id);
			JOptionPane.showMessageDialog(this, "Consulta exclu�da com sucesso!");
			clearFields();
			listaConsulta = new ConsultaController().listaConsulta();
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(this, "Nao foi possivel excluir o contato!n" + e.getLocalizedMessage());
		}
	}

	private void clickConsultar() {
		ConsultaController cc = new ConsultaController();

		try {
			Consulta m = cc.buscaConsultaPorNome(nm_paciente.getText());
			nm_medico.setText(m.getNm_medico());
			vIdade.setText(m.getIdade());
			cSexo.setText(m.getSexo());
			txtData.setText(new SimpleDateFormat("dd/MM/yyyy").format(m.getDt_nasc_pac()));
			tp_consulta.setText(m.getTp_consulta());
			tp_medico.setText(m.getTp_medico());
			nm_medico.setText(m.getNm_medico());
			txtDataCad.setText(new SimpleDateFormat("dd/MM/yyyy").format(m.getDt_consulta()));
			vmatricula.setText(m.getMatricula_pac());
			cObs.setText(m.getObs_pac());
			
			

		} catch (SQLException e) {
			JOptionPane.showMessageDialog(this, "Ocorreu um erro, tente novamente!n" + e.getLocalizedMessage());
		} catch (NullPointerException e) {
			JOptionPane.showMessageDialog(this, "Consulta n�o localizada ou n�o existe!n" + e.getLocalizedMessage());
		}

	}

	private void clearFields() {
		cObs.setText("");
		nm_paciente.setText("");
		tp_consulta.setText("");
		tp_medico.setText("");
		vIdade.setText("");
		nm_medico.setText("");
		cSexo.setText("");
		txtData.setText("");
		vmatricula.setText("");
		txtData.setText("");
		txtDataCad.setText("");
	}

	public static void main(String[] args) {

		new ConsultaFrame().setVisible(true);

	}
}
