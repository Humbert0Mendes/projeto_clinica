package view;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import model.UsuarioDao;

public final class Login extends JFrame {

	private JPanel login;
	private JTextField cdLogin;
	JPasswordField cdSenha;

	public Login() {
		setTitle("Consulta R�pida");
		setSize(800, 600);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setLayout(null);

		// Painel Login
		login = new JPanel();
		login.setBounds(30, 50, 700, 700);
		setContentPane(login);
		login.setLayout(null);
		login.setSize(700, 500);
		login.setBorder(new EmptyBorder(5, 5, 5, 5));

		// Campo Login
		JLabel campoLogin = new JLabel("Login");
		campoLogin.setFont(new Font("Tahoma", Font.BOLD, 18));
		campoLogin.setBounds(370, 235, 70, 30);

		cdLogin = new JTextField();
		cdLogin.setBounds(265, 265, 250, 35);
		login.add(cdLogin);
		login.add(campoLogin);

		// Campo Senha

		JLabel campoSenha = new JLabel("Senha");
		campoSenha.setFont(new Font("Tahoma", Font.BOLD, 18));
		campoSenha.setBounds(365, 295, 70, 30);

		cdSenha = new JPasswordField();
		cdSenha.setBounds(290, 325, 200, 35);
		login.add(cdSenha);
		login.add(campoSenha);

		// Bot�o entrar
		JButton btEntrar = new JButton("Entrar");
		btEntrar.setFont(new Font("Tahoma", Font.BOLD, 18));
		btEntrar.setBackground(new Color(20, 28, 100));
		btEntrar.setForeground(new Color(0, 0, 0));
		btEntrar.setBounds(340, 380, 100, 35);
		login.add(btEntrar);

		btEntrar.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				clickEntrar();
			}
		});

	}

	private void clickEntrar() {

		UsuarioDao usr = new UsuarioDao();
		try {
			if (usr.checkUsuario(cdLogin.getText(), cdSenha.getText())) {
				new TelaAdmin().setVisible(true);
				this.dispose();
			} else {
				JOptionPane.showMessageDialog(null, "Crendenciais Inv�lidas");
			}

		} catch (SQLException e) {

			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		new Login().setVisible(true);
	}

}
