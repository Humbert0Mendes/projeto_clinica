package view;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import controller.MedicoController;
import model.Medico;

public class MedicoFrame extends JFrame {

	JPanel cadastraMedico;
	JLabel Titulo;
	private JButton btnSalvar, btnExcluir, btnLimpar, btnConsultar;
	private JTextField nm_medico, vIdade, cSexo, txtData, txtCPF, vProfissao, cEspec, cd_conselho;

	private List medicoList = new MedicoController().listaMedicos();
	private int registroAtual = 0;
	private Long key;

	JMenuBar menuPrincipal = new JMenuBar();
	JMenu menuArquivo = new JMenu("Menu");
	JMenu outros = new JMenu("Outros");
	JMenu novoCad = new JMenu("Novo Cadastro");
	JMenu consulta = new JMenu("Consultar Cadastros");

	JMenuItem inicio = new JMenuItem("In�cio");
	JMenuItem novoCadMed = new JMenuItem("Cadastro M�dico");
	JMenuItem novoCadPac = new JMenuItem("Cadastro Paciente");
	JMenuItem cCadMed = new JMenuItem("Consultar M�dico");
	JMenuItem cCadPac = new JMenuItem("Consultar Paciente");
	JMenuItem sair = new JMenuItem("Sair");

	public MedicoFrame() {

		setTitle("Cadastro M�dico");
		setSize(800, 600);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setLayout(null);

		// Tela de Cadastrar M�dico
		cadastraMedico = new JPanel();
		cadastraMedico.setBounds(30, 50, 700, 700);
		setContentPane(cadastraMedico);
		cadastraMedico.setLayout(null);
		cadastraMedico.setSize(700, 500);
		cadastraMedico.setBorder(new EmptyBorder(5, 5, 5, 5));

		setJMenuBar(menuPrincipal);
		menuPrincipal.add(menuArquivo);
		menuArquivo.add(inicio);
		menuArquivo.add(novoCad);
		menuArquivo.add(consulta);
		menuArquivo.add(sair);
		novoCad.add(novoCadMed);
		novoCad.add(novoCadPac);
		consulta.add(cCadMed);
		consulta.add(cCadPac);

		// A��es do Menu
		
		// A��es do Menu

				// Chamando Tela Inicial
				inicio.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent chamaIni) {
						TelaAdmin tAdm = new TelaAdmin();
						tAdm.setVisible(true);
					}
				});

				// Chamando novo Cadastro M�dico
				novoCadMed.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent chamaTela) {
						MedicoFrame cadMed = new MedicoFrame();
						cadMed.setVisible(true);
					}
				});

				// Chamando Cadastro Paciente
				novoCadPac.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent chamaPac) {
						PacienteFrame cadPac = new PacienteFrame();
						cadPac.setVisible(true);
					}
				});

				// Chamando Consulta de Paciente
				cCadMed.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent chamaConMed) {
						ConsultaPacienteFrame consPac = new ConsultaPacienteFrame();
						consPac.setVisible(true);
					}
				});

				// Chamando Consulta de M�dico
				cCadPac.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent chamaConPac) {
						ConsultaMedicoFrame consMed = new ConsultaMedicoFrame();
						consMed.setVisible(true);

					}
				});

				// Chamando Tela de Login
				sair.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent chamaLog) {
						Login tLogin = new Login();
						tLogin.setVisible(true);
					}
				});


		// Campo Nome
		JLabel nomeMedico = new JLabel("Nome");
		nomeMedico.setFont(new Font("Tahoma", Font.BOLD, 10));
		nomeMedico.setBounds(30, 5, 70, 20);

		nm_medico = new JTextField();
		nm_medico.setBounds(30, 27, 250, 25);
		cadastraMedico.add(nomeMedico);
		cadastraMedico.add(nm_medico);

		// Campo Idade
		JLabel idade = new JLabel("Idade");
		idade.setFont(new Font("Tahoma", Font.BOLD, 10));
		idade.setBounds(300, 5, 70, 20);

		vIdade = new JTextField();
		vIdade.setBounds(300, 27, 50, 25);
		cadastraMedico.add(idade);
		cadastraMedico.add(vIdade);

		// Campo Sexo
		JLabel lSexo = new JLabel("Sexo");
		lSexo.setFont(new Font("Tahoma", Font.BOLD, 10));
		lSexo.setBounds(370, 5, 70, 20);
		cadastraMedico.add(lSexo);

		cSexo = new JTextField();
		cSexo.setFont(new Font("Tahoma", Font.BOLD, 10));
		cSexo.setBounds(370, 27, 180, 25);
		cadastraMedico.add(cSexo);

		// Campo Data
		JLabel lData = new JLabel("Data Nascimento");
		lData.setFont(new Font("Tahoma", Font.BOLD, 10));
		lData.setBounds(570, 5, 90, 20);
		cadastraMedico.add(lData);

		txtData = new JTextField();
		txtData.setBounds(570, 27, 80, 25);
		cadastraMedico.add(txtData);

		// Campo CPF
		JLabel cpf = new JLabel("CPF");
		cpf.setFont(new Font("Tahoma", Font.BOLD, 10));
		cpf.setBounds(30, 50, 70, 20);
		cadastraMedico.add(cpf);

		txtCPF = new JTextField();
		txtCPF.setBounds(30, 70, 250, 25);
		cadastraMedico.add(txtCPF);

		// Campo Profiss�o
		JLabel prestador = new JLabel("Tipo Prestador");
		prestador.setFont(new Font("Tahoma", Font.BOLD, 10));
		prestador.setBounds(300, 50, 90, 20);

		vProfissao = new JTextField();
		vProfissao.setBounds(300, 70, 250, 25);
		cadastraMedico.add(prestador);
		cadastraMedico.add(vProfissao);

		// Campo Especialidade
		JLabel espec = new JLabel("Especialidade");
		espec.setFont(new Font("Tahoma", Font.BOLD, 10));
		espec.setBounds(30, 100, 70, 20);
		cadastraMedico.add(espec);

		cEspec = new JTextField();
		cEspec.setBounds(30, 120, 250, 25);
		cadastraMedico.add(cEspec);

		// Campo Conselho

		JLabel conselho = new JLabel("Conselho");
		conselho.setFont(new Font("Tahoma", Font.BOLD, 10));
		conselho.setBounds(300, 100, 70, 20);

		cd_conselho = new JTextField();
		cd_conselho.setBounds(300, 120, 250, 25);
		cadastraMedico.add(conselho);
		cadastraMedico.add(cd_conselho);

		// Bot�o Limpar
		btnLimpar = new JButton("Limpar");
		btnLimpar.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnLimpar.setBackground(new Color(20, 28, 100));
		btnLimpar.setForeground(new Color(255, 255, 255));
		btnLimpar.setBounds(570, 120, 120, 25);
		cadastraMedico.add(btnLimpar);

		// Bot�o Salvar
		btnSalvar = new JButton("Salvar");
		btnSalvar.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnSalvar.setBackground(new Color(20, 28, 100));
		btnSalvar.setForeground(new Color(255, 255, 255));
		btnSalvar.setBounds(340, 380, 100, 35);
		cadastraMedico.add(btnSalvar);

		// Bot�o Consultar
		btnConsultar = new JButton("Consultar M�dico");
		btnConsultar.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnConsultar.setBackground(new Color(20, 28, 100));
		btnConsultar.setForeground(new Color(255, 255, 255));
		btnConsultar.setBounds(30, 160, 180, 25);
		cadastraMedico.add(btnConsultar);

		// Bot�o excluir
		btnExcluir = new JButton("Excluir");
		btnExcluir.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnExcluir.setBackground(new Color(20, 28, 100));
		btnExcluir.setForeground(new Color(255, 255, 255));
		btnExcluir.setBounds(540, 180, 120, 25);
		cadastraMedico.add(btnExcluir);

		// Implementando a��o dos bot�es
		// Salvar
		btnSalvar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				clickSalvar();
			}
		});

		// Excluir
		btnExcluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				clickExcluir();
			}
		});

		// Limpar
		btnLimpar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				clearFields();
				registroAtual = 0;
			}

		});

		// Consultar
		btnConsultar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				clickConsultar();
			}
		});

	}

	private void clickSalvar() {
		MedicoController mc = new MedicoController();

		try {
			mc.salvar(nm_medico.getText(), txtCPF.getText(), cSexo.getText(), vIdade.getText(), vProfissao.getText(),
					cd_conselho.getText(), cEspec.getText(), txtData.getText());
			JOptionPane.showMessageDialog(this, "M�dico salvo com sucesso!");
			clearFields();
			medicoList = new MedicoController().listaMedicos();
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(this, "Nao foi possivel salvar contato!n" + e.getLocalizedMessage());
		} catch (ParseException e) {
			JOptionPane.showMessageDialog(this, "Data possui formato inv�lido!n" + e.getLocalizedMessage());
		}
	}

	private void clickExcluir() {
		MedicoController mc = new MedicoController();
		long id = ((Medico) medicoList.get(registroAtual)).getId();

		try {
			mc.excluir(id);
			JOptionPane.showMessageDialog(this, "M�dico excluido com sucesso!");
			clearFields();
			medicoList = new MedicoController().listaMedicos();
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(this, "Nao foi possivel excluir o contato!n" + e.getLocalizedMessage());
		}
	}

	private void clearFields() {

		nm_medico.setText("");
		vProfissao.setText("");
		cEspec.setText("");
		vIdade.setText("");
		cSexo.setText("");
		cd_conselho.setText("");
		txtData.setText("");
		txtCPF.setText("");
	}

	private void clickConsultar() {
		MedicoController mc = new MedicoController();

		try {
			Medico m = mc.buscarMedicoPorNome(nm_medico.getText());
			nm_medico.setText(m.getNm_medico());
			txtCPF.setText(m.getCpf());
			cSexo.setText(m.getSexo());
			vIdade.setText(m.getIdade());
			vProfissao.setText(m.getTp_prestador());
			cd_conselho.setText(m.getConselho());
			cEspec.setText(m.getEspec());
			txtData.setText(new SimpleDateFormat("dd/MM/yyyy").format(m.getDt_nascimento()));

		} catch (SQLException e) {
			JOptionPane.showMessageDialog(this, "Ocorreu um erro, tente novamente!n" + e.getLocalizedMessage());
		} catch (NullPointerException e) {
			JOptionPane.showMessageDialog(this, "M�dico n�o localizado ou n�o existe!n" + e.getLocalizedMessage());
		}

	}

	public static void main(String[] args) {
		new MedicoFrame().setVisible(true);
	}
}
