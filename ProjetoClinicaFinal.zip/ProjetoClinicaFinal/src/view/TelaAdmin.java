package view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

public class TelaAdmin extends JFrame{
	
	JMenuBar menuPrincipal = new JMenuBar();

	JMenu menuArquivo = new JMenu("Menu");
	JMenu outros = new JMenu("Outros");
	JMenu novoCad = new JMenu("Novo Cadastro");
	JMenu consulta = new JMenu("Consultar Cadastros");

	JMenuItem inicio = new JMenuItem("In�cio");
	JMenuItem novoCadMed = new JMenuItem("Cadastro M�dico");
	JMenuItem novoCadPac = new JMenuItem("Cadastro Paciente");
	JMenuItem novaConsulta = new JMenuItem("Nova Consulta");
	JMenuItem cCadMed = new JMenuItem("Consultar M�dico");
	JMenuItem cCadPac = new JMenuItem("Consultar Paciente");
	JMenuItem sair = new JMenuItem("Sair");

	public TelaAdmin() {

		setJMenuBar(menuPrincipal);
		menuPrincipal.add(menuArquivo);
		menuArquivo.add(inicio);
		menuArquivo.add(novaConsulta);
		menuArquivo.add(novoCad);
		menuArquivo.add(consulta);
		menuArquivo.add(sair);
		novoCad.add(novoCadMed);
		novoCad.add(novoCadPac);
		consulta.add(cCadMed);
		consulta.add(cCadPac);

		// A��es do Menu

		// Chamando novo Cadastro M�dico
		novoCadMed.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent chamaTela) {
				MedicoFrame cadMed = new MedicoFrame();
				cadMed.setVisible(true);
			}
		});

		// Chamando Cadastro Paciente
		novoCadPac.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent chamaPac) {
				PacienteFrame cadPac = new PacienteFrame();
				cadPac.setVisible(true);
			}
		});
		
		//Chamando Tela de Marcar Consulta
		novaConsulta.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent chamaCons) {
				ConsultaFrame cons = new ConsultaFrame();
				cons.setVisible(true);
			}
		});

		// Chamando Consulta de Paciente
	/*	cCadMed.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent chamaConMed) {
				ConsultaPaciente consPac = new ConsultaPaciente();
				consPac.setVisible(true);
			}
		});*/

		// Chamando Consulta de M�dico
		cCadPac.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent chamaConPac) {

			}
		});

		// Chamando Tela de Login
		sair.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent chamaLog) {
				Login tLogin = new Login();
				tLogin.setVisible(true);
			}
		});

		setTitle("Consulta Flex");
		setSize(800, 600);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setVisible(true);

	}


	
	public static void main(String[] args) {
		TelaAdmin tadm = new TelaAdmin();
		tadm.setVisible(true);
	}
}
