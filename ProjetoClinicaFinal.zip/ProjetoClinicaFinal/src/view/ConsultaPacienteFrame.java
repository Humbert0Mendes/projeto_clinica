package view;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import controller.PacienteController;
import model.Paciente;

public class ConsultaPacienteFrame extends JFrame {
	
	JPanel cadastraPaciente;
	JLabel Titulo;

	private JTextField nm_paciente, vIdade, vmatricula, vFamilia, tpSangue, cObs, vDoenca, txtData, txtCpf, cSexo;
	private JCheckBox cCronica;
	private JButton btnExcluir, btnLimpar, btnConsultar;

	private List pacienteList = new PacienteController().listaPacientes();
	private int registroAtual = 0;
	private Long key;

	JMenuBar menuPrincipal = new JMenuBar();
	JMenu menuArquivo = new JMenu("Menu");
	JMenu outros = new JMenu("Outros");
	JMenu novoCad = new JMenu("Novo Cadastro");
	JMenu consulta = new JMenu("Consultar Cadastros");

	JMenuItem inicio = new JMenuItem("In�cio");
	JMenuItem novoCadMed = new JMenuItem("Cadastro M�dico");
	JMenuItem novoCadPac = new JMenuItem("Cadastro Paciente");
	JMenuItem cCadMed = new JMenuItem("Consultar M�dico");
	JMenuItem cCadPac = new JMenuItem("Consultar Paciente");
	JMenuItem sair = new JMenuItem("Sair");

	public ConsultaPacienteFrame() {

		setTitle("Cadastro do Paciente");
		setSize(800, 600);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setLayout(null);

		setJMenuBar(menuPrincipal);
		menuPrincipal.add(menuArquivo);
		menuArquivo.add(inicio);
		menuArquivo.add(novoCad);
		menuArquivo.add(consulta);
		menuArquivo.add(sair);
		novoCad.add(novoCadMed);
		novoCad.add(novoCadPac);
		consulta.add(cCadMed);
		consulta.add(cCadPac);

		// Tela de Cadastrar Paciente
		cadastraPaciente = new JPanel();
		cadastraPaciente.setBounds(30, 50, 700, 700);
		setContentPane(cadastraPaciente);
		cadastraPaciente.setLayout(null);
		cadastraPaciente.setSize(700, 500);
		cadastraPaciente.setBorder(new EmptyBorder(5, 5, 5, 5));

		// Bot�es

		// Bot�o Consultar
		btnConsultar = new JButton("Consultar");
		btnConsultar.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnConsultar.setBackground(new Color(20, 28, 100));
		btnConsultar.setForeground(new Color(255, 255, 255));
		btnConsultar.setBounds(30, 240, 180, 25);
		cadastraPaciente.add(btnConsultar);

		// Bot�o Limpar
		btnLimpar = new JButton("Limpar");
		btnLimpar.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnLimpar.setBackground(new Color(20, 28, 100));
		btnLimpar.setForeground(new Color(255, 255, 255));
		btnLimpar.setBounds(340, 180, 120, 25);
		cadastraPaciente.add(btnLimpar);

		// Bot�o excluir
		btnExcluir = new JButton("Excluir");
		btnExcluir.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnExcluir.setBackground(new Color(20, 28, 100));
		btnExcluir.setForeground(new Color(255, 255, 255));
		btnExcluir.setBounds(440, 180, 120, 25);
		cadastraPaciente.add(btnExcluir);

		// A��es do Menu
		// Verificar a melhor forma de colocar aqui

		// Campos dados do Paciente

		// Campo Nome
		JLabel nomePaciente = new JLabel("Nome");
		nomePaciente.setFont(new Font("Tahoma", Font.BOLD, 10));
		nomePaciente.setBounds(30, 5, 70, 20);

		nm_paciente = new JTextField();
		nm_paciente.setBounds(30, 27, 250, 25);
		cadastraPaciente.add(nomePaciente);
		cadastraPaciente.add(nm_paciente);

		// Campo Idade
		JLabel idade = new JLabel("Idade");
		idade.setFont(new Font("Tahoma", Font.BOLD, 10));
		idade.setBounds(300, 5, 70, 20);

		vIdade = new JTextField();
		vIdade.setBounds(300, 27, 50, 25);
		cadastraPaciente.add(idade);
		cadastraPaciente.add(vIdade);

		// Campo Sexo
		JLabel lSexo = new JLabel("Sexo");
		lSexo.setFont(new Font("Tahoma", Font.BOLD, 10));
		lSexo.setBounds(370, 5, 70, 20);
		cadastraPaciente.add(lSexo);

		cSexo = new JTextField();
		cSexo.setFont(new Font("Tahoma", Font.BOLD, 10));
		cSexo.setBounds(370, 27, 180, 25);
		cadastraPaciente.add(cSexo);

		// Campo Data
		JLabel lData = new JLabel("Data Nascimento");
		lData.setFont(new Font("Tahoma", Font.BOLD, 10));
		lData.setBounds(570, 5, 90, 20);
		cadastraPaciente.add(lData);

		txtData = new JTextField();
		txtData.setBounds(570, 27, 80, 25);
		cadastraPaciente.add(txtData);

		// Campo CPF
		JLabel cpf = new JLabel("CPF");
		cpf.setFont(new Font("Tahoma", Font.BOLD, 10));
		cpf.setBounds(30, 50, 70, 20);
		cadastraPaciente.add(cpf);

		JTextField txtCPF = new JTextField();
		txtCPF.setBounds(30, 70, 250, 25);
		cadastraPaciente.add(txtCPF);

		// Campo Familiar
		JLabel paiMae = new JLabel("Pai/M�e");
		paiMae.setFont(new Font("Tahoma", Font.BOLD, 10));
		paiMae.setBounds(300, 50, 70, 20);

		vFamilia = new JTextField();
		vFamilia.setBounds(300, 70, 250, 25);
		cadastraPaciente.add(paiMae);
		cadastraPaciente.add(vFamilia);

		// Campo Matricula
		JLabel matricula = new JLabel("Matr�cula");
		matricula.setFont(new Font("Tahoma", Font.BOLD, 10));
		matricula.setBounds(570, 100, 90, 20);
		cadastraPaciente.add(matricula);

		vmatricula = new JTextField();
		vmatricula.setBounds(570, 120, 80, 25);
		cadastraPaciente.add(vmatricula);

		// Doen�a Cr�nica
		JLabel lDoenca = new JLabel("Doen�a Cr�nica?");
		lDoenca.setFont(new Font("Tahoma", Font.BOLD, 10));
		lDoenca.setBounds(30, 100, 90, 20);

		cCronica = new JCheckBox("Doen�a Cr�nica");
		cCronica.setBounds(30, 120, 20, 20);
		cadastraPaciente.add(cCronica);

		vDoenca = new JTextField();
		vDoenca.setBounds(50, 120, 230, 25);
		cadastraPaciente.add(lDoenca);
		cadastraPaciente.add(vDoenca);

		// Tipo Sangue
		JLabel lSangue = new JLabel("Tipo Sangu�neo");
		lSangue.setFont(new Font("Tahoma", Font.BOLD, 10));
		lSangue.setBounds(300, 100, 90, 20);
		cadastraPaciente.add(lSangue);

		tpSangue = new JTextField();
		tpSangue.setBounds(300, 120, 250, 25);
		cadastraPaciente.add(tpSangue);

		// Campo Obs
		JLabel lObs = new JLabel("Observa��o");
		lObs.setFont(new Font("Tahoma", Font.BOLD, 10));
		lObs.setBounds(30, 150, 70, 20);
		cadastraPaciente.add(lObs);

		cObs = new JTextField();
		cObs.setFont(new Font("Tahoma", Font.BOLD, 10));
		cObs.setBounds(30, 170, 300, 50);
		cadastraPaciente.add(cObs);

		// Excluir
		btnExcluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				clickExcluir();
			}
		});

		// Limpar
		btnLimpar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				clearFields();
				registroAtual = 0;
			}

		});

		// Consultar
		btnConsultar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				clickConsultar();
			}
		});
	}

	private void clickSalvar() {
		PacienteController pc = new PacienteController();

		try {
			pc.salvar(nm_paciente.getText(), cSexo.getText(), vFamilia.getText(), vDoenca.getText(), txtCpf.getText(),
					vmatricula.getText(), vIdade.getText(), txtData.getText(), tpSangue.getText(), cObs.getText());
			JOptionPane.showMessageDialog(this, "Paciente salvo com sucesso!");
			clearFields();
			pacienteList = new PacienteController().listaPacientes();
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(this, "Nao foi possivel salvar contato!n" + e.getLocalizedMessage());
		} catch (ParseException e) {
			JOptionPane.showMessageDialog(this, "Data possui formato inv�lido!n" + e.getLocalizedMessage());
		}
	}

	private void clickExcluir() {
		PacienteController pc = new PacienteController();
		long id = ((Paciente) pacienteList.get(registroAtual)).getId();

		try {
			pc.excluir(id);
			JOptionPane.showMessageDialog(this, "Paciente excluido com sucesso!");
			clearFields();
			pacienteList = new PacienteController().listaPacientes();
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(this, "Nao foi possivel excluir o contato!n" + e.getLocalizedMessage());
		}
	}

	private void clearFields() {
		cObs.setText("");
		nm_paciente.setText("");
		tpSangue.setText("");
		vDoenca.setText("");
		vIdade.setText("");
		vFamilia.setText("");
		cSexo.setText("");
		cCronica.setSelected(false);
		vmatricula.setText("");
		txtData.setText("");
		txtCpf.setText("");
	}

	private void clickConsultar() {
		PacienteController pc = new PacienteController();

		try {
			Paciente p = pc.buscaPacientePorNome(nm_paciente.getText());
			nm_paciente.setText(p.getNome());
			cSexo.setText(p.getSexo());
			vFamilia.setText(p.getParente());
			vDoenca.setText(p.getDoenca());
			txtCpf.setText(p.getCpf());
			vmatricula.setText(p.getMatricula());
			vIdade.setText(p.getIdade());
			txtData.setText(new SimpleDateFormat("dd/MM/yyyy").format(p.getDt_nasc()));
			tpSangue.setText(p.getTp_sangue());
			cObs.setText(p.getObs());

		} catch (SQLException e) {
			JOptionPane.showMessageDialog(this, "Ocorreu um erro, tente novamente!n" + e.getLocalizedMessage());
		} catch (NullPointerException e) {
			JOptionPane.showMessageDialog(this, "Motorista n�o localizado ou n�o existe!n" + e.getLocalizedMessage());
		}
	}

	public static void main(String[] args) {
		new ConsultaPacienteFrame().setVisible(true);
	}

	
	

}
