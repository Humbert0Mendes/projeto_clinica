package controller;

import java.sql.Date;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.swing.JOptionPane;

import model.Consulta;
import model.ConsultaDao;
import model.Paciente;
import model.PacienteDao;

public class ConsultaController {

	private Date formatarData(String data) throws ParseException {
		DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		return new Date(formatter.parse(data).getTime());
	}

	public void salvar(String nome, String idade, String sexo, String dt_nasc_pac, String tp_consulta, String tp_medico,
			String nm_medico, String dt_consulta, String matricula, String obs_pac)
			throws SQLException, ParseException {
		Consulta consulta = new Consulta();
		consulta.setNm_paciente(nome);
		consulta.setIdade(idade);
		consulta.setSexo(sexo);
		consulta.setDt_nasc_pac(formatarData(dt_nasc_pac));
		consulta.setTp_consulta(tp_consulta);
		consulta.setTp_medico(tp_medico);
		consulta.setDt_consulta(formatarData(dt_consulta));
		consulta.setMatricula_pac(matricula);
		consulta.setObs_pac(obs_pac);

		new ConsultaDao().salvar(consulta);
	}

	public void excluir(long id) throws SQLException {
		new ConsultaDao().excluir(id);
	}

	public List listaConsulta() {
		ConsultaDao dao = new ConsultaDao();
		try {
			return dao.findListaConsulta();
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Problemas ao localizar Consultas" + e.getLocalizedMessage());
		}
		return null;
	}

	public Consulta buscaConsultaPorNome(String nome) throws SQLException {
		ConsultaDao dao = new ConsultaDao();
		return dao.findByName(nome);
	}

}
