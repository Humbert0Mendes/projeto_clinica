package controller;

import java.sql.Date;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.swing.JOptionPane;

import model.Paciente;
import model.PacienteDao;

public class PacienteController {

	private Date formatarData(String data) throws ParseException {
		DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		return new Date(formatter.parse(data).getTime());
	}

	public void salvar(String nome, String sexo, String nm_familiar, String doenca_cronica, String cpf,
			String matricula, String idade, String dt_nasc, String tp_sangue, String observacao)
			throws SQLException, ParseException {
		Paciente paciente = new Paciente();
		paciente.setNome(nome);
		paciente.setSexo(sexo);
		paciente.setDoenca(doenca_cronica);
		paciente.setParent(nm_familiar);
		paciente.setCpf(cpf);
		paciente.setMatricula(matricula);
		paciente.setIdade(idade);
		paciente.setDt_nasc(formatarData(dt_nasc));
		paciente.setTp_sangue(tp_sangue);
		paciente.setObs(observacao);
		new PacienteDao().salvar(paciente);
	}

	public void excluir(long id) throws SQLException {
		new PacienteDao().excluir(id);
	}

	public List listaPacientes() {
		PacienteDao dao = new PacienteDao();
		try {
			return dao.findPacientes();
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Problemas ao localizar Pacientes" + e.getLocalizedMessage());
		}
		return null;
	}

	public Paciente buscaPacientePorNome(String nome) throws SQLException {
		PacienteDao dao = new PacienteDao();
		return dao.findByName(nome);
	}

}
