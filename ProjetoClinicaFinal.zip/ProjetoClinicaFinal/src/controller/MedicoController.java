package controller;

import java.sql.Date;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.swing.JOptionPane;

import model.Medico;
import model.MedicoDao;

public class MedicoController {

	private Date formatarData(String data) throws ParseException {
		DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		return new Date(formatter.parse(data).getTime());
	}

	public void salvar(String nm_medico, String cpf, String sexo, String idade, String tp_prestador, String conselho,
			String espec, String dt_nascimento) throws SQLException, ParseException {
		Medico medico = new Medico();
		medico.setNm_medico(nm_medico);
		medico.setCpf(cpf);
		medico.setSexo(sexo);
		medico.setIdade(idade);
		medico.setTp_prestador(tp_prestador);
		medico.setConselho(conselho);
		medico.setEspec(espec);
		medico.setDt_nascimento(formatarData(dt_nascimento));
		new MedicoDao().salvar(medico);

	}

	public void excluir(long id) throws SQLException {
		new MedicoDao().excluir(id);
	}

	public List listaMedicos() {
		MedicoDao dao = new MedicoDao();
		try {
			return dao.findListaMedico();
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Problemas ao localizar M�dicos" + e.getLocalizedMessage());
		}
		return null;
	}

	public Medico buscarMedicoPorNome(String nm_medico) throws SQLException {
		MedicoDao dao = new MedicoDao();
		return dao.findByName(nm_medico);
	}
}
